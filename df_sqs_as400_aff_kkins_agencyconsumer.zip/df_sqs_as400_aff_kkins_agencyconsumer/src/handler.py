import os, math
import json
import time
import logging
import pandas as pd
import asyncio
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import func, and_,select, BIGINT, create_engine, Column, update, Integer, cast, String, MetaData, DateTime, Float, Text, DECIMAL, TIMESTAMP, text
from df_database_models.db_conn import get_rds_db_session, get_as400_db_session
from df_database_models.models import Line_Item, Line_Item_Type, Invoice, Source_System, Invoice_Status, Agency
from df_database_models.db_utils import (
    generate_uuid, convert_timestamps, query_update_dict, get_record, multi_filter_get_record
)
from secrets_manager import get_secret
from adf_pyutils.clm_wrapper import common_logger

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# # --- Env DB Configs ---
pnc_db = os.environ['RDS_DB_NAME']
ref_db = os.environ['RDS_REF_DB_NAME']
mdm_raw_db = os.environ['RDS_RAW_DB_NAME']
mdm_refined_db = os.environ['RDS_REFINED_DB_NAME']

# --- Async Logger Wrapper ---
async def log_msg(func, **kwargs):
    await asyncio.to_thread(func, **kwargs)

def call_session_engine(source_system=None, database_name=None):
 
    rds_secret_name=os.environ["RDS_SECRETS_MANAGER_ID"]
    region_name=os.environ["AWS_REGION"]
    rds_host_nm=os.environ['RDS_HOST']
 
    if database_name == 'ref_data':
        rds_db_nm=os.environ['RDS_REF_DB_NAME']
    elif database_name == 'mdm_raw':
        rds_db_nm=os.environ['RDS_RAW_DB_NAME']
    elif database_name == 'mdm_refined':
        rds_db_nm=os.environ['RDS_REFINED_DB_NAME']
    else:
        rds_db_nm=os.environ['RDS_DB_NAME']
 
    if source_system and source_system.lower() == 'as400_affprd':
        #Calling the as400 engine to establish a connection to PAS Source System - as400_AFF
        as400_secret_name=os.environ["AS400_AFF_SECRETS_MANAGER_ID"]
        as400_engine=get_as400_db_session(as400_secret_name, region_name)
        return as400_engine
 
    elif source_system and source_system.lower() == 'as400_kkins':
        #Calling the as400 engine to establish a connection to PAS Source System - as400_AUM
        as400_secret_name=os.environ["AS400_KKINS_SECRETS_MANAGER_ID"]
        as400_engine=get_as400_db_session(as400_secret_name, region_name)
        return as400_engine
 
    if database_name:
        #Calling the Db session Object to establish a connection to Data Foundation Schema
        session=get_rds_db_session(rds_secret_name,region_name,rds_host_nm,rds_db_nm)
 
        return session

session = call_session_engine(database_name=pnc_db)
as400_engine_aff = call_session_engine(source_system='as400_affprd')
as400_engine_kkins = call_session_engine(source_system='as400_kkins')

# lookup into as400 aff
def lookup_as400(config=None, id=None):

    source_system = config['source_system']
    if source_system:
        if(source_system.lower() == 'as400_affprd'):
                df = pd.read_sql(f"""
                    SELECT DISTINCT 
                    LTRIM(RTRIM(SUBPNO)) AS source_agency_id,
                    LTRIM(RTRIM(SUBPNO)) AS agency_id,
                    CASE 
                        WHEN LOWER(LTRIM(RTRIM(SUACTI))) = 'n' THEN 'Not active'
                        WHEN LOWER(LTRIM(RTRIM(SUACTI))) = 'y' THEN 'Active'
                        ELSE NULL
                    END AS agency_status,
                    LTRIM(RTRIM(SUTXID)) AS tax_id,
                    LTRIM(RTRIM(SUBANM)) AS legal_name,
                    LTRIM(RTRIM(SUBANM)) AS dba_name,
                    'AS400_AFFPRD' AS source_system,
                    CAST(NULL AS varchar(255)) AS source_system_id,
                    CAST(NULL AS varchar(255)) AS parent_agency_id,
                    CAST(NULL AS varchar(255)) AS source_company_type,
                    CAST(NULL AS varchar(255)) AS industry_type,
                    CAST(NULL AS varchar(255)) AS sic_code,
                    CAST(NULL AS varchar(255)) AS naics_code,
                    CAST(NULL AS varchar(255)) AS created_date,
                    CAST(NULL AS varchar(255)) AS modified_date,
                    CAST(NULL AS varchar(255)) AS df_agency_id,
                    CAST(NULL AS varchar(255)) AS mdm_agency_id,
                    LTRIM(RTRIM(SUBAD1)) AS premises_address_line1,
                    LTRIM(RTRIM(SUBAD2)) AS premises_address_line2,
                    LTRIM(RTRIM(SUBCTY)) AS premises_city,
                    LTRIM(RTRIM(SUBSTC)) AS premises_state,
                    LTRIM(RTRIM([SUPHN#])) AS premises_phone,
                    LTRIM(RTRIM([SUFAX#])) AS premises_fax,
                    LTRIM(RTRIM(SUBZIP)) AS premises_zip_code,
                    LTRIM(RTRIM(SUBAD1)) AS billing_address_line1,
                    LTRIM(RTRIM(SUBAD2)) AS billing_address_line2,
                    LTRIM(RTRIM(SUBCTY)) AS billing_city,
                    LTRIM(RTRIM(SUBSTC)) AS billing_state,
                    LTRIM(RTRIM([SUPHN#])) AS billing_phone,
                    LTRIM(RTRIM([SUFAX#])) AS billing_fax,
                    LTRIM(RTRIM(SUBZIP)) AS billing_zip_code,
                    LTRIM(RTRIM(SUBAD1)) AS mail_address_line1,
                    LTRIM(RTRIM(SUBAD2)) AS mail_address_line2,
                    LTRIM(RTRIM(SUBCTY)) AS mail_city,
                    LTRIM(RTRIM(SUBSTC)) AS mail_state,
                    LTRIM(RTRIM([SUPHN#])) AS mail_phone,
                    LTRIM(RTRIM([SUFAX#])) AS mail_fax,
                    LTRIM(RTRIM(SUBZIP)) AS mail_zip_code,
                    LTRIM(RTRIM(SUWEBA)) AS website
                FROM adgdtadv.adgsubp
                Where LTRIM(RTRIM(SUBPNO)) = '{id}';
                    """, con=as400_engine_aff)

        elif(source_system.lower() == 'as400_kkins'):
                df = pd.read_sql(f"""
                        SELECT DISTINCT 
                        (CAST(agcy.AGY_OFFICE as varchar(255)) + '-' + CAST(agcy.AGY_NUMBER as varchar(255))) AS source_agency_id,
                        'AS400_KKINS' AS source_system,
                        CAST(NULL AS varchar(36)) AS mdm_agency_id,
                        CAST(NULL AS DATETIME) AS created_date,
                        CAST(NULL AS DATETIME) AS modified_date
                    FROM [PLCYPROD].[APZ001] AS agcy
                    INNER JOIN [PLCYPROD].[APZ002] AS agnt 
                        ON agcy.AGY_OFFICE = agnt.AGT_OFF_CODE 
                        AND agcy.AGY_NUMBER = agnt.AGY_AGENT_NBR
                    INNER JOIN [PLCYPROD].[APZ001TG] AS gt 
                        ON agcy.AGY_OFFICE = gt.AGY_OFFICE 
                        AND agcy.AGY_NUMBER = gt.AGY_NUMBER
                    INNER JOIN [PLCYPROD].[AUZ002] AS pl 
                        ON agnt.AGY_AGENT_NBR = pl.AGY_AGENT_NBR 
                        AND agnt.AGY_AGENT_CODE = pl.AGY_AGENT_CODE
                    WHERE (CAST(agcy.AGY_OFFICE as varchar(255)) + '-' + CAST(agcy.AGY_NUMBER as varchar(255))) = '{id}';
                        """, con=as400_engine_kkins)
    else:
        df=None

    if(len(df)>0):
        return df.to_dict('records')
    else:
        return None

def consume_lambda(config=None):
    """
    Ingestion script for Agency table.
    Matches your existing pattern for other entities (policy, AI, invoice, coverage allocation).
    Does NOT insert into any master table. Only inserts/updates into agency.
    """

    now = datetime.now()
    start_ts = datetime.timestamp(now)

    logger.info(f"Processing AS400 Agency @ {now}")

    try:
        # Normalize config
        config_list = (
            config if isinstance(config, list)
            else [json.loads(config)] if isinstance(config, str)
            else [config]
        )

        for cfg in config_list:

            src_agency_id = cfg.get("source_agency_id")
            source_system = cfg.get("source_system", "").lower()

            if not src_agency_id:
                logger.info(f"Missing source_agency_id")
                continue

            logger.info(f"Invoking handler for agency {src_agency_id} from {source_system}"
                )

            # -----------------------------------------------------------------
            # 1. FETCH AGENCY FROM AS400 (YOU PROVIDE DICT SAME AS OTHER ENTITY)
            # -----------------------------------------------------------------

            as400_agency_dicts = lookup_as400(config=cfg, id=src_agency_id)

            if not type(as400_agency_dicts) is list:
                as400_agency_dicts = [as400_agency_dicts]

            for as400_agency_dict in as400_agency_dicts:

                if not as400_agency_dict:
                    logger.info(f"No AS400 agency record found for {src_agency_id}")
                    continue

                logger.info(f"AS400 Agency Data Fetched")

                # -----------------------------------------------------------------
                # 2. FK LOOKUP — source_system (DO NOT INSERT)
                # -----------------------------------------------------------------

                ss_rec = session.query(Source_System).filter(
                    Source_System.source_system == as400_agency_dict.get("source_system")
                ).first()

                if ss_rec:
                    as400_agency_dict["df_source_system_id"] = ss_rec.df_source_system_id
                else:
                    logger.info(f"Source system not found — skipping agency {src_agency_id}")
                    continue

                df_source_system_id = as400_agency_dict["df_source_system_id"]

                # -----------------------------------------------------------------
                # LOOKUP existing Agency
                # -----------------------------------------------------------------

                existing_agency = session.query(Agency).filter(
                    Agency.source_agency_id == as400_agency_dict.get('source_agency_id'),
                    Agency.df_source_system_id == df_source_system_id
                ).first()

                # -----------------------------------------------------------------
                # 4. INSERT logic
                # -----------------------------------------------------------------

                if not existing_agency:

                    df_agency_id = generate_uuid(
                        str(src_agency_id)
                    )
                    
                    as400_agency_dict["df_agency_id"] = df_agency_id
                    as400_agency_dict["created_at"] = datetime.now()
                    as400_agency_dict["modified_at"] = None
                    session.add(
                        Agency.from_dict(cls=Agency, d=as400_agency_dict)
                    )
                    session.commit()

                    logger.info(f"Inserted Agency {src_agency_id}"
                        )

                # -----------------------------------------------------------------
                # 5. UPDATE logic
                # -----------------------------------------------------------------

                else:
                    as400_agency_dict["df_agency_id"] = existing_agency.df_agency_id
                    as400_agency_dict["created_at"] = existing_agency.created_at
                    as400_agency_dict["modified_at"] = datetime.now()

                    q = session.query(Agency).filter(
                        Agency.df_agency_id == existing_agency.df_agency_id
                    )
                    q.update(query_update_dict(obj=Agency, dict=as400_agency_dict))
                    session.commit()

                    logger.info(f"Updated Agency {src_agency_id}"
                        )
        end_ts = datetime.timestamp(datetime.now())
        return {"execution_time_sec": end_ts - start_ts}

    except SQLAlchemyError as error:
        session.rollback()
        logger.info(f"DB Error")
        raise error


def handle(event, context):
    start_time = time.time()
    failures = []

    for record in event.get("Records", []):
        logger.info(record)
        payload = record.get("body")
        try:

            consume_lambda(config=payload)   # sync call is correct
        except Exception:
            message_id = record.get("messageId")
            if message_id:
                failures.append({"itemIdentifier": message_id})
            else:
                logger.error("Record missing messageId: %s", record, exc_info=True)

    end_time = time.time()
    logger.info("Lambda handle duration: %.3f seconds", end_time - start_time)

    return {
        "batchItemFailures": failures
    }


# if __name__ == '__main__':
#     handle({'Records': [{'body': '{"source_agency_id":"FW-3261", "source_system" : "AS400_KKINS"}'}]}, None)
    